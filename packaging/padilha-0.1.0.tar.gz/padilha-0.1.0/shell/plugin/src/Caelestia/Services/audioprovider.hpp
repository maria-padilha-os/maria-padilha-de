#pragma once

#include <qqmlintegration.h>
#include <qtimer.h>

#include "service.hpp"

namespace caelestia::services {

class AudioProcessor : public QObject {
    Q_OBJECT

public:
    explicit AudioProcessor(QObject* parent = nullptr);
    ~AudioProcessor() override;

    void init();

public slots:
    void start();
    void stop();

protected:
    virtual void process() = 0;

private:
    QTimer* m_timer = nullptr;
};

class AudioProvider : public Service {
    Q_OBJECT

public:
    explicit AudioProvider(QObject* parent = nullptr);
    ~AudioProvider() override;

protected:
    AudioProcessor* m_processor;

    void init();

private:
    QThread* m_thread;

    void start() override;
    void stop() override;
};

} // namespace caelestia::services
