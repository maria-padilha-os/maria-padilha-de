#pragma once

#include <qbytearray.h>
#include <qbytearrayview.h>
#include <qfuturewatcher.h>
#include <qhash.h>
#include <qpointer.h>
#include <qqmlintegration.h>
#include <qqmllist.h>
#include <qvariant.h>

#include "diskinfo.hpp"
#include "tickingservice.hpp"

namespace caelestia::services {

class Storage : public TickingService {
    Q_OBJECT
    QML_ELEMENT
    QML_SINGLETON

    Q_PROPERTY(qreal percentage READ percentage NOTIFY percentageChanged)
    Q_PROPERTY(QQmlListProperty<caelestia::services::DiskInfo> disks READ disksProp NOTIFY disksChanged)
    Q_PROPERTY(caelestia::services::DiskInfo* manualPrimaryDisk READ manualPrimaryDisk WRITE setManualPrimaryDisk NOTIFY
            manualPrimaryDiskChanged)
    Q_PROPERTY(caelestia::services::DiskInfo* primaryDisk READ primaryDisk NOTIFY primaryDiskChanged)

public:
    explicit Storage(QObject* parent = nullptr);

    [[nodiscard]] qreal percentage() const;
    [[nodiscard]] QQmlListProperty<DiskInfo> disksProp();
    [[nodiscard]] DiskInfo* manualPrimaryDisk() const;
    void setManualPrimaryDisk(DiskInfo* disk);
    [[nodiscard]] DiskInfo* primaryDisk() const;

signals:
    void disksChanged();
    void percentageChanged();
    void manualPrimaryDiskChanged();
    void primaryDiskChanged();

protected:
    void tick() override;

private:
    // One physical disk (or zfs pool), accumulated across the filesystems on it
    struct Accum {
        quint64 usedBytes = 0;
        quint64 totalBytes = 0;
        bool hasRoot = false;
    };

    using AccumHash = QHash<QString, Accum>;

    // Mounts sharing a backing filesystem report identical usage, so they are deduped by source device first
    struct DeviceEntry {
        quint64 totalBytes = 0;
        quint64 usedBytes = 0;
        bool hasRoot = false;
        QByteArray device;
        QByteArray fsType;
    };

    [[nodiscard]] static QHash<QByteArray, DeviceEntry> collectDevices();
    [[nodiscard]] static AccumHash foldToDisks(const QHash<QByteArray, DeviceEntry>& byDevice);

    void applyDisks(const AccumHash& byDisk);

    [[nodiscard]] static QStringList resolveToPhysicalDisks(const QString& devicePath);
    [[nodiscard]] static bool isPseudoFs(QByteArrayView fsType);
    [[nodiscard]] static bool sameOrder(const QList<DiskInfo*>& a, const QList<DiskInfo*>& b);

    static qsizetype disksCount(QQmlListProperty<DiskInfo>* prop);
    static DiskInfo* disksAt(QQmlListProperty<DiskInfo>* prop, qsizetype i);

    QList<DiskInfo*> m_disks;
    QPointer<DiskInfo> m_manualPrimaryDisk;
    QFutureWatcher<AccumHash>* const m_futureWatcher;
};

} // namespace caelestia::services
