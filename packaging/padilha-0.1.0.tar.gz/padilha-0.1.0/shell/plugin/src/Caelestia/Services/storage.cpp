#include "storage.hpp"

#include <qdir.h>
#include <qfile.h>
#include <qfileinfo.h>
#include <qhash.h>
#include <qstorageinfo.h>
#include <qtconcurrentrun.h>

#include <sys/stat.h>
#include <sys/sysmacros.h>

#include <algorithm>
#include <cmath>

namespace caelestia::services {

using Qt::StringLiterals::operator""_s;

namespace {

[[nodiscard]] QString sysfsRealPath(uint major, uint minor) {
    const QString link = u"/sys/dev/block/%1:%2"_s.arg(major).arg(minor);
    const QString resolved = QFileInfo(link).canonicalFilePath();
    return resolved;
}

[[nodiscard]] bool readDevtFromSysfs(const QString& sysfsBlockDir, uint& major, uint& minor) {
    QFile f(sysfsBlockDir + u"/dev"_s);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return false;
    }
    const QByteArray line = f.readLine().trimmed();
    f.close();

    const qsizetype colon = line.indexOf(':');
    if (colon <= 0) {
        return false;
    }
    bool okM = false;
    bool okN = false;
    major = line.left(colon).toUInt(&okM);
    minor = line.mid(colon + 1).toUInt(&okN);
    return okM && okN;
}

QStringList resolveByDevt(uint major, uint minor, int depth = 0);

QStringList resolveAtNode(const QString& node, int depth) {
    if (node.isEmpty() || depth > 8) {
        return {};
    }

    const QFileInfo nodeInfo(node);
    if (!nodeInfo.exists() || !nodeInfo.isDir()) {
        return {};
    }

    if (QFileInfo::exists(node + u"/partition"_s)) {
        const QString diskNode = nodeInfo.path();
        return { QFileInfo(diskNode).fileName() };
    }

    const QDir slavesDir(node + u"/slaves"_s);
    if (slavesDir.exists()) {
        const QStringList slaves = slavesDir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
        if (!slaves.isEmpty()) {
            QStringList out;
            for (const QString& slave : slaves) {
                uint sm = 0;
                uint sn = 0;
                const QString slaveDir = u"/sys/class/block/"_s + slave;
                if (!readDevtFromSysfs(slaveDir, sm, sn)) {
                    continue;
                }
                const auto devs = resolveByDevt(sm, sn, depth + 1);
                for (const QString& d : devs) {
                    if (!out.contains(d)) {
                        out.append(d);
                    }
                }
            }
            return out;
        }
    }

    return { nodeInfo.fileName() };
}

QStringList resolveByDevt(uint major, uint minor, int depth) {
    return resolveAtNode(sysfsRealPath(major, minor), depth);
}

} // namespace

Storage::Storage(QObject* parent)
    : TickingService(parent)
    , m_futureWatcher(new QFutureWatcher<AccumHash>(this)) {
    QObject::connect(m_futureWatcher, &QFutureWatcher<AccumHash>::finished, this, [this] {
        applyDisks(m_futureWatcher->result());
    });
}

qreal Storage::percentage() const {
    qreal totalUsed = 0.0;
    qreal totalSize = 0.0;
    for (const DiskInfo* d : m_disks) {
        totalUsed += d->used();
        totalSize += d->total();
    }
    return totalSize > 0.0 ? totalUsed / totalSize : 0.0;
}

bool Storage::sameOrder(const QList<DiskInfo*>& a, const QList<DiskInfo*>& b) {
    if (a.size() != b.size()) {
        return false;
    }
    for (qsizetype i = 0; i < a.size(); ++i) {
        if (a.at(i) != b.at(i)) {
            return false;
        }
    }
    return true;
}

QQmlListProperty<DiskInfo> Storage::disksProp() {
    return { this, nullptr, &Storage::disksCount, &Storage::disksAt };
}

qsizetype Storage::disksCount(QQmlListProperty<DiskInfo>* prop) {
    return static_cast<Storage*>(prop->object)->m_disks.size();
}

DiskInfo* Storage::disksAt(QQmlListProperty<DiskInfo>* prop, qsizetype i) {
    return static_cast<Storage*>(prop->object)->m_disks.at(i);
}

DiskInfo* Storage::manualPrimaryDisk() const {
    return m_manualPrimaryDisk.data();
}

void Storage::setManualPrimaryDisk(DiskInfo* disk) {
    if (m_manualPrimaryDisk.data() == disk) {
        return;
    }
    m_manualPrimaryDisk = disk;
    emit manualPrimaryDiskChanged();
    emit primaryDiskChanged();
}

DiskInfo* Storage::primaryDisk() const {
    if (auto* m = m_manualPrimaryDisk.data()) {
        return m;
    }
    return m_disks.isEmpty() ? nullptr : m_disks.first();
}

bool Storage::isPseudoFs(QByteArrayView fsType) {
    static constexpr const char* k_pseudo[] = {
        "tmpfs",
        "devtmpfs",
        "proc",
        "sysfs",
        "cgroup",
        "cgroup2",
        "overlay",
        "squashfs",
        "devpts",
        "mqueue",
        "ramfs",
        "rpc_pipefs",
        "autofs",
        "configfs",
        "debugfs",
        "tracefs",
        "securityfs",
        "pstore",
        "bpf",
        "binfmt_misc",
        "hugetlbfs",
        "fusectl",
        "efivarfs",
        "selinuxfs",
    };
    for (const char* p : k_pseudo) {
        if (fsType == QByteArrayView(p)) {
            return true;
        }
    }
    return fsType.startsWith(QByteArrayView("fuse."));
}

QStringList Storage::resolveToPhysicalDisks(const QString& devicePath) {
    if (devicePath.isEmpty() || !devicePath.startsWith(u'/')) {
        return {};
    }
    struct stat st{};
    if (::stat(devicePath.toLocal8Bit().constData(), &st) != 0) {
        return {};
    }
    if (!S_ISBLK(st.st_mode)) {
        return {};
    }
    return resolveByDevt(major(st.st_rdev), minor(st.st_rdev));
}

QHash<QByteArray, Storage::DeviceEntry> Storage::collectDevices() {
    QHash<QByteArray, DeviceEntry> byDevice;

    const auto mountedVols = QStorageInfo::mountedVolumes();
    for (const QStorageInfo& v : mountedVols) {
        if (!v.isReady() || !v.isValid() || v.bytesTotal() <= 0)
            continue;
        if (isPseudoFs(QByteArrayView(v.fileSystemType())))
            continue;

        const auto device = v.device();
        const auto totalBytes = static_cast<quint64>(v.bytesTotal());
        const auto availBytes = static_cast<quint64>(v.bytesAvailable());
        const auto usedBytes = totalBytes > availBytes ? totalBytes - availBytes : 0;
        const auto isRoot = v.rootPath() == u"/"_s;

        DeviceEntry& e = byDevice[device];
        e.device = device;
        e.fsType = v.fileSystemType();
        e.totalBytes = totalBytes;
        e.usedBytes = usedBytes;
        e.hasRoot = e.hasRoot || isRoot;
    }

    return byDevice;
}

Storage::AccumHash Storage::foldToDisks(const QHash<QByteArray, DeviceEntry>& byDevice) {
    AccumHash byDisk;

    for (auto it = byDevice.constBegin(); it != byDevice.constEnd(); ++it) {
        const auto& e = it.value();
        const auto disks = resolveToPhysicalDisks(QString::fromLocal8Bit(e.device));

        if (disks.isEmpty()) {
            // ZFS has no /dev block device to resolve, its "device" is a
            // "pool/dataset" name (e.g. rpool/root), so resolveToPhysicalDisks
            // returns nothing and the whole pool would be dropped. Fall back to
            // keying by the pool name. Datasets in a pool share the pool's free
            // space, so keep a single representative entry per pool (preferring
            // the root dataset, else the largest) rather than summing them.
            if (e.fsType != QByteArrayView("zfs"))
                continue;

            const auto slash = e.device.indexOf('/');
            const auto pool = QString::fromLocal8Bit(slash > 0 ? e.device.left(slash) : e.device);
            Accum& a = byDisk[pool];
            if (!a.hasRoot && (e.hasRoot || e.totalBytes > a.totalBytes)) {
                a.usedBytes = e.usedBytes;
                a.totalBytes = e.totalBytes;
                a.hasRoot = e.hasRoot;
            }
            continue;
        }

        for (const auto& d : disks) {
            if (d.startsWith(u"zram"_s))
                continue;

            Accum& a = byDisk[d];
            a.usedBytes += e.usedBytes;
            a.totalBytes += e.totalBytes;
            a.hasRoot = a.hasRoot || e.hasRoot;
        }
    }

    return byDisk;
}

void Storage::tick() {
    if (m_futureWatcher->isRunning())
        return;

    m_futureWatcher->setFuture(QtConcurrent::run([] {
        return foldToDisks(collectDevices());
    }));
}

void Storage::applyDisks(const AccumHash& byDisk) {
    const auto prevPercentage = percentage();

    QHash<QString, DiskInfo*> existing;
    existing.reserve(m_disks.size());

    for (auto* const d : std::as_const(m_disks))
        existing.insert(d->mount(), d);

    QList<DiskInfo*> next;
    next.reserve(byDisk.size());
    for (auto it = byDisk.constBegin(); it != byDisk.constEnd(); ++it) {
        if (auto* const survivor = existing.take(it.key())) {
            survivor->update(it.value().usedBytes, it.value().totalBytes, it.value().hasRoot);
            next.append(survivor);
        } else {
            next.append(new DiskInfo(it.key(), it.value().usedBytes, it.value().totalBytes, it.value().hasRoot, this));
        }
    }

    std::ranges::sort(next, [](const DiskInfo* a, const DiskInfo* b) {
        if (a->hasRoot() != b->hasRoot())
            return a->hasRoot();
        return a->mount() < b->mount();
    });

    bool manualCleared = false;
    if (const auto* m = m_manualPrimaryDisk.data(); m && existing.contains(m->mount())) {
        m_manualPrimaryDisk.clear();
        manualCleared = true;
    }
    for (auto* const stale : std::as_const(existing))
        stale->deleteLater();

    const auto listChanged = !sameOrder(m_disks, next);
    const auto* prevPrimary = primaryDisk();
    m_disks = next;

    if (listChanged)
        emit disksChanged();
    if (std::abs(percentage() - prevPercentage) > 0.0001)
        emit percentageChanged();
    if (manualCleared)
        emit manualPrimaryDiskChanged();
    if (primaryDisk() != prevPrimary)
        emit primaryDiskChanged();
}

} // namespace caelestia::services
