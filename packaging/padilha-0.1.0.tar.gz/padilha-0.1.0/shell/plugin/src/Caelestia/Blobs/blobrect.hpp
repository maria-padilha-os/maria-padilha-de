#pragma once

#include <qelapsedtimer.h>
#include <qpointer.h>
#include <qqmlengine.h>
#include <qqmllist.h>

#include "blobshape.hpp"

namespace caelestia::blobs {

class BlobRect : public BlobShape {
    Q_OBJECT
    QML_ELEMENT
    Q_PROPERTY(qreal stiffness READ stiffness WRITE setStiffness NOTIFY stiffnessChanged)
    Q_PROPERTY(qreal damping READ damping WRITE setDamping NOTIFY dampingChanged)
    Q_PROPERTY(qreal deformScale READ deformScale WRITE setDeformScale NOTIFY deformScaleChanged)
    Q_PROPERTY(QQmlListProperty<caelestia::blobs::BlobRect> exclude READ exclude NOTIFY excludeChanged)
    Q_PROPERTY(
        QQmlListProperty<caelestia::blobs::BlobRect> excludeCorners READ excludeCorners NOTIFY excludeCornersChanged)
    Q_PROPERTY(qreal topLeftRadius READ topLeftRadius WRITE setTopLeftRadius NOTIFY topLeftRadiusChanged)
    Q_PROPERTY(qreal topRightRadius READ topRightRadius WRITE setTopRightRadius NOTIFY topRightRadiusChanged)
    Q_PROPERTY(qreal bottomLeftRadius READ bottomLeftRadius WRITE setBottomLeftRadius NOTIFY bottomLeftRadiusChanged)
    Q_PROPERTY(
        qreal bottomRightRadius READ bottomRightRadius WRITE setBottomRightRadius NOTIFY bottomRightRadiusChanged)

public:
    explicit BlobRect(QQuickItem* parent = nullptr);
    ~BlobRect() override;

    [[nodiscard]] qreal stiffness() const;
    void setStiffness(qreal s);

    [[nodiscard]] qreal damping() const;
    void setDamping(qreal damping);

    [[nodiscard]] qreal deformScale() const;
    void setDeformScale(qreal s);

    QQmlListProperty<BlobRect> exclude();
    QQmlListProperty<BlobRect> excludeCorners();

    [[nodiscard]] qreal topLeftRadius() const;
    void setTopLeftRadius(qreal r);

    [[nodiscard]] qreal topRightRadius() const;
    void setTopRightRadius(qreal r);

    [[nodiscard]] qreal bottomLeftRadius() const;
    void setBottomLeftRadius(qreal r);

    [[nodiscard]] qreal bottomRightRadius() const;
    void setBottomRightRadius(qreal r);

signals:
    void stiffnessChanged();
    void dampingChanged();
    void deformScaleChanged();
    void excludeChanged();
    void excludeCornersChanged();
    void topLeftRadiusChanged();
    void topRightRadiusChanged();
    void bottomLeftRadiusChanged();
    void bottomRightRadiusChanged();

protected:
    void updatePolish() override;
    void updatePhysics() override;

    [[nodiscard]] bool isExcluded(const BlobShape* other) const override;
    [[nodiscard]] bool isCornerExcluded(const BlobShape* other) const override;
    void cornerRadii(float out[4]) const override;

private:
    void checkAtRest(float speed);

    // Physics state
    QPointF m_prevScenePos;
    QElapsedTimer m_elapsed;
    bool m_physicsActive = false;
    bool m_hasPrevPos = false;

    // Symmetric 2x2 deformation matrix components (3 independent: m00, m01,
    // m11) Rest state is identity: m00=1, m01=0, m11=1
    float m_dm00 = 1.0f;
    float m_dm01 = 0.0f;
    float m_dm11 = 1.0f;

    // Spring velocities for each component
    float m_dmVel00 = 0.0f;
    float m_dmVel01 = 0.0f;
    float m_dmVel11 = 0.0f;

    qreal m_stiffness = 200.0;
    qreal m_damping = 16.0;
    qreal m_deformScale = 0.0005;

    qreal m_topLeftRadius = -1;
    qreal m_topRightRadius = -1;
    qreal m_bottomLeftRadius = -1;
    qreal m_bottomRightRadius = -1;

    QList<QPointer<BlobRect>> m_exclude;
    QList<QPointer<BlobRect>> m_excludeCorners;

    static void excludeAppend(QQmlListProperty<BlobRect>* prop, BlobRect* rect);
    static qsizetype excludeCount(QQmlListProperty<BlobRect>* prop);
    static BlobRect* excludeAt(QQmlListProperty<BlobRect>* prop, qsizetype index);
    static void excludeClear(QQmlListProperty<BlobRect>* prop);
    static void excludeReplace(QQmlListProperty<BlobRect>* prop, qsizetype index, BlobRect* rect);
    static void excludeRemoveLast(QQmlListProperty<BlobRect>* prop);

    static void excludeCornersAppend(QQmlListProperty<BlobRect>* prop, BlobRect* rect);
    static qsizetype excludeCornersCount(QQmlListProperty<BlobRect>* prop);
    static BlobRect* excludeCornersAt(QQmlListProperty<BlobRect>* prop, qsizetype index);
    static void excludeCornersClear(QQmlListProperty<BlobRect>* prop);
    static void excludeCornersReplace(QQmlListProperty<BlobRect>* prop, qsizetype index, BlobRect* rect);
    static void excludeCornersRemoveLast(QQmlListProperty<BlobRect>* prop);
};

} // namespace caelestia::blobs
