pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Layouts
import M3Shapes
import Caelestia.Config
import qs.components
import qs.components.controls
import qs.modules.lock
import qs.services

StyledRect {
    id: root

    required property real centerScale
    required property int centerWidth
    required property var lock

    implicitWidth: {
        const w = centerWidth * 0.8;
        return lock.pam.buffer ? w : Math.min(w, inputField.placeholderWidth + iconWrapper.implicitWidth + enterButton.implicitWidth + input.spacing * 2 + Tokens.padding.medium * 2);
    }
    implicitHeight: input.implicitHeight + Tokens.padding.small

    color: Colours.tPalette.m3surfaceContainer
    radius: Tokens.rounding.full

    // The lock UI draws the password from pam.buffer itself, so typing goes
    // through an invisible TextInput. A real text control is what lets Qt's
    // input method (QT_IM_MODULE=compose) turn ABNT2 dead-key sequences such
    // as ' + a into á, instead of dropping the accent on the floor.
    focus: false
    onActiveFocusChanged: {
        if (!activeFocus && !textInput.activeFocus)
            textInput.forceActiveFocus();
    }

    TextInput {
        id: textInput

        width: 1
        height: 1
        opacity: 0
        focus: true
        echoMode: TextInput.Password
        selectByMouse: false

        Component.onCompleted: forceActiveFocus()

        onTextChanged: {
            if (root.lock.pam.buffer !== text)
                root.lock.pam.buffer = text;
        }

        onAccepted: {
            if (root.lock.unlocking || root.lock.pam.passwd.active || root.lock.pam.state === Pam.MaxTries)
                return;

            inputField.placeholder.animate = false;

            if (root.lock.pam.howdy.canAttempt && !root.lock.pam.howdy.active && text.length === 0)
                root.lock.pam.howdy.start();
            else
                root.lock.pam.passwd.start();
        }

        Keys.onPressed: event => {
            if (event.key === Qt.Key_Backspace && (event.modifiers & Qt.ControlModifier)) {
                text = "";
                event.accepted = true;
            }
        }
    }

    Connections {
        target: root.lock.pam

        function onBufferChanged(): void {
            if (root.lock.pam.buffer === "" && textInput.text !== "")
                textInput.text = "";
        }
    }

    Behavior on implicitWidth {
        Anim {}
    }

    StateLayer {
        hoverEnabled: false
        cursorShape: Qt.IBeamCursor
        onClicked: textInput.forceActiveFocus()
    }

    RowLayout {
        id: input

        anchors.fill: parent
        anchors.margins: Tokens.padding.extraSmall
        spacing: Tokens.spacing.medium

        Item {
            id: iconWrapper

            Layout.fillHeight: true
            implicitWidth: height

            AnimLoader {
                anchors.centerIn: parent
                anchors.verticalCenterOffset: sourceComponent === iconComp ? 1 : 0
                sourceComp: root.lock.pam.passwd.active || root.lock.pam.howdy.active ? loadingComp : iconComp
            }

            Component {
                id: iconComp

                MaterialIcon {
                    animate: true
                    text: {
                        if (inputField.showPassword)
                            return "visibility";
                        if (root.lock.pam.fprint.tries >= GlobalConfig.lock.maxFprintTries) {
                            if (root.lock.pam.howdy.canAttempt)
                                return "face";
                            return "fingerprint_off";
                        }
                        if (root.lock.pam.fprint.active)
                            return "fingerprint";
                        if (root.lock.pam.howdy.canAttempt)
                            return "face";
                        return "lock";
                    }
                    color: !root.lock.pam.howdy.canAttempt && root.lock.pam.fprint.tries >= GlobalConfig.lock.maxFprintTries ? Colours.palette.m3error : Colours.palette.m3onSurfaceVariant
                    fontStyle: Tokens.font.icon.builders.medium.scale(root.centerScale).build()
                    fill: text === "face" || text === "visibility"

                    StateLayer {
                        anchors.fill: undefined
                        anchors.centerIn: parent
                        implicitWidth: {
                            const w = parent.implicitHeight + Tokens.padding.small * 2;
                            return w + (w % 2);
                        }
                        implicitHeight: implicitWidth
                        radius: Tokens.rounding.full

                        onClicked: {
                            parent.animate = false;
                            inputField.showPassword = !inputField.showPassword;
                            parent.animate = true;
                        }
                    }
                }
            }

            Component {
                id: loadingComp

                LoadingIndicator {
                    implicitSize: iconWrapper.height - Tokens.padding.small * 2
                }
            }
        }

        InputField {
            id: inputField

            Layout.fillWidth: true
            Layout.fillHeight: true

            centerScale: root.centerScale
            pam: root.lock.pam
        }

        Item {
            id: enterButton

            implicitWidth: implicitHeight
            implicitHeight: {
                const h = enterIcon.implicitHeight + Tokens.padding.extraSmall * 2;
                return h % 2 === 0 ? h : h + 1;
            }

            MaterialShape {
                anchors.fill: parent

                color: root.lock.pam.buffer ? Colours.palette.m3primary : Colours.layer(Colours.palette.m3surfaceContainerHigh, 2)
                shape: root.lock.pam.buffer ? MaterialShape.Arrow : MaterialShape.Circle
                scale: !root.lock.pam.buffer ? 1 : mouse.pressed ? 0.6 : mouse.containsMouse ? 0.8 : 0.7
                rotation: 90

                Behavior on scale {
                    Anim {
                        type: Anim.FastSpatial
                    }
                }

                Behavior on color {
                    CAnim {}
                }

                MouseArea {
                    id: mouse

                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: root.lock.pam.buffer ? Qt.PointingHandCursor : Qt.ArrowCursor
                    onClicked: root.lock.pam.buffer && root.lock.pam.passwd.start()
                }
            }

            MaterialIcon {
                id: enterIcon

                anchors.centerIn: parent
                text: "arrow_forward"
                color: Colours.palette.m3onSurfaceVariant
                fontStyle: Tokens.font.icon.builders.medium.scale(root.centerScale * 1.2).build()
                opacity: root.lock.pam.buffer ? 0 : 1

                Behavior on opacity {
                    Anim {
                        type: Anim.DefaultEffects
                    }
                }
            }
        }
    }
}
